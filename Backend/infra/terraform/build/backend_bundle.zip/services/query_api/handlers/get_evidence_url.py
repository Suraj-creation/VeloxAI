from __future__ import annotations

from services.query_api.repositories.evidence_repo import EvidenceRepository


def handle_get_evidence_url(repo: EvidenceRepository, violation_id: str, evidence_type: str) -> dict:
    return repo.build_signed_url(violation_id=violation_id, evidence_type=evidence_type)

from __future__ import annotations

from datetime import datetime, timedelta, timezone


class EvidenceRepository:
    def build_signed_url(self, violation_id: str, evidence_type: str) -> dict:
        expires_at = datetime.now(timezone.utc) + timedelta(minutes=10)
        return {
            "url": f"https://example.invalid/evidence/{violation_id}/{evidence_type}",
            "expires_at": expires_at.isoformat(),
        }

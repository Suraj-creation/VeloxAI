# FootWatch Backend

Modular backend scaffold for Objective 3 enforcement ingestion and dashboard query APIs.

## Quick Start

1. Create a virtual environment.
2. Install dependencies.
3. Run ingest API, query API, and worker.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn services.ingest_api.app:app --reload --port 8000
.\.venv\Scripts\python.exe -m uvicorn services.query_api.app:app --reload --port 8001
.\.venv\Scripts\python.exe -m services.workers.process_violation_queue.handler
```

Set frontend API base URL to `http://localhost:8001` while testing dashboard reads.

This scaffold keeps edge inference local and ingests telemetry plus confirmed violation metadata only.
